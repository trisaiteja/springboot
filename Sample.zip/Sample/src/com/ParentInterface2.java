package com;

public interface ParentInterface2 {
	void m1();
}
