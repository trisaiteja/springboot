package com;

@CopyRight
public interface MySupplier<T> {
	T get();
}
