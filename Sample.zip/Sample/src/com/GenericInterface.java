package com;

@CopyRight
public interface GenericInterface<T> {
	T getGenericType();
}
