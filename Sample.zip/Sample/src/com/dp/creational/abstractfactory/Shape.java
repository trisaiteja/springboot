package com.dp.creational.abstractfactory;

import com.CopyRight;

@CopyRight
public interface Shape {
	void draw();
}
