package com.dp.creational.builder;

import com.CopyRight;

@CopyRight
public class Box implements Packaging {

	@Override
	public String pack() {
		return "Box";
	}

}
