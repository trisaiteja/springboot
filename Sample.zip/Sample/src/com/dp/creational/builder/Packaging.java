package com.dp.creational.builder;

import com.CopyRight;

@CopyRight
public interface Packaging {
	String pack();
}
