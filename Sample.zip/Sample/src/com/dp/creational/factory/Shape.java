package com.dp.creational.factory;

import com.CopyRight;

@CopyRight
public interface Shape {
	void draw();
}
