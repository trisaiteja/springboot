package com.dp.creational.singleton;

import com.CopyRight;

@CopyRight
public class SingletonPatternDemo {

	public static void main(String[] args) {
		SingletonDesignPattern.getInstance().print1();
	}

}
