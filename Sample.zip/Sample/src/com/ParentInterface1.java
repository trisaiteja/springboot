package com;

public interface ParentInterface1 {
	void m1();
}
