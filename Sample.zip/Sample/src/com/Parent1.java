package com;

public class Parent1 {
	
	public static void main(String[] args) {
		System.out.println("main in Parent1");
	}
	
	public static void main(int[] args) {
		System.out.println("main overloading....");
	}
}
