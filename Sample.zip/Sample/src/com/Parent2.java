package com;

public class Parent2 {
	private void m1() {
		System.out.println("Parent2 m1");
	}
}
